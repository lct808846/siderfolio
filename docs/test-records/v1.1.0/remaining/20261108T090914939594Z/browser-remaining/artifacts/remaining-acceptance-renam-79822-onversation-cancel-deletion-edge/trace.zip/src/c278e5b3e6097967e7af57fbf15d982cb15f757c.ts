import { test, expect, type APIRequestContext } from '@playwright/test'
import { readFile } from 'node:fs/promises'

async function conversation(request: APIRequestContext, title: string) {
  const response = await request.post('/api/v1/conversations', { data: { title } })
  expect(response.status()).toBe(201)
  return response.json()
}

test('clipboard preserves the question and reports a denied copy', async ({ page, request }) => {
  const item = await conversation(request, '复制验收')
  const question = '合成查询第一行\n第二行 Gaia 5853498713190525696'
  const turn = await request.post(`/api/v1/conversations/${item.id}/turns`, { data: { message: question, client_request_id: crypto.randomUUID(), expected_revision: 0 } })
  expect(turn.status()).toBe(200)
  await page.addInitScript(() => {
    Object.defineProperty(navigator, 'clipboard', { configurable: true, value: { writeText: async (value: string) => {
      const state = window as unknown as { copied: string; rejectCopy: boolean }
      if (state.rejectCopy) throw new Error('denied')
      state.copied = value
    } } })
  })
  await page.goto(`/conversations/${item.id}`)
  await page.getByRole('button', { name: '复制第1轮问题' }).click()
  expect(await page.evaluate(() => (window as unknown as { copied: string }).copied)).toBe(question)
  await page.evaluate(() => { (window as unknown as { rejectCopy: boolean }).rejectCopy = true })
  await page.getByRole('button', { name: '复制第1轮问题' }).click()
  await expect(page.getByRole('alert')).toContainText('复制未完成')
})

test('pending response does not open results and manual close survives refresh', async ({ page }) => {
  let release!: () => void
  const gate = new Promise<void>(resolve => { release = resolve })
  await page.route('**/api/v1/conversations/*/turns', async route => { await gate; await route.continue() }, { times: 1 })
  try {
    await page.goto('/')
    await page.getByRole('textbox', { name: '天文问题' }).fill('合成 Gaia 查询')
    await page.getByRole('button', { name: '发送问题' }).click()
    await expect(page.getByText('正在处理，请稍候…')).toBeVisible()
    await expect(page.locator('.conversation-layout')).toHaveAttribute('data-results-open', 'false')
    release()
    await expect(page.getByRole('button', { name: '收起结果面板' })).toBeVisible()
    await page.getByRole('button', { name: '收起结果面板' }).click()
    await page.reload()
    await expect(page.locator('.conversation-layout')).toHaveAttribute('data-results-open', 'false')
  } finally { release() }
})

test('rename, pin and export a noncurrent conversation; cancel deletion', async ({ page, request }) => {
  const first = await conversation(request, '当前验收会话')
  const other = await conversation(request, '其他验收会话')
  await page.goto(`/conversations/${first.id}`)
  await page.getByRole('button', { name: '会话操作：其他验收会话' }).click()
  await page.getByRole('menuitem', { name: '重命名' }).click()
  await page.getByRole('textbox', { name: '会话名称' }).fill('已改名验收会话')
  await page.getByRole('button', { name: '保存名称' }).click()
  await expect(page.getByRole('heading', { name: '当前验收会话' })).toBeVisible()
  await page.getByRole('button', { name: '会话操作：已改名验收会话' }).click()
  await page.getByRole('menuitem', { name: '置顶', exact: true }).click()
  await expect(page.locator('.conversation-row').first()).toContainText('已改名验收会话')
  await page.getByRole('button', { name: '会话操作：已改名验收会话' }).click()
  await page.getByRole('menuitem', { name: '导出会话 JSON' }).click()
  const downloaded = page.waitForEvent('download')
  await page.getByRole('button', { name: '确认下载 JSON' }).click()
  const file = await downloaded
  const body = JSON.parse(await readFile((await file.path())!, 'utf8'))
  expect(body.conversation.id).toBe(other.id)
  expect(body.conversation.title).toBe('已改名验收会话')
  await page.getByRole('button', { name: '多选' }).click()
  await page.getByLabel('选择会话 已改名验收会话').check()
  await page.getByRole('button', { name: '删除所选' }).click()
  await expect(page.getByRole('dialog')).toContainText('已改名验收会话')
  await page.getByRole('dialog').getByRole('button', { name: '取消' }).click()
  expect((await request.get(`/api/v1/conversations/${other.id}`)).status()).toBe(200)
})

test('settings refresh failure clears the previous ready status', async ({ page }) => {
  let calls = 0
  await page.route('**/api/v1/setup/status', async route => {
    calls++
    if (calls === 1) await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ configured: true, ready: true, message: '合成数据库已就绪', code: 'ready', database_version: 'test', database_schema: 6, vector_version: 'test' }) })
    else await route.fulfill({ status: 503, contentType: 'application/json', body: JSON.stringify({ error: { code: 'database_unavailable', message: '合成读取失败', retryable: true } }) })
  })
  await page.goto('/settings')
  await expect(page.getByText('业务数据库已就绪')).toBeVisible()
  await page.getByRole('button', { name: '刷新本机状态' }).click()
  await expect(page.getByRole('alert')).toContainText('合成读取失败')
  await expect(page.getByText('本机状态未确认')).toBeVisible()
  await expect(page.getByText('业务数据库已就绪')).toHaveCount(0)
})
