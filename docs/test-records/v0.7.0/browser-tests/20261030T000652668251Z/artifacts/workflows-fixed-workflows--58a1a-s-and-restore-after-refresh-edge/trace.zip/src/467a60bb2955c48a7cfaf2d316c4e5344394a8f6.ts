import { test, expect } from '@playwright/test'
import path from 'node:path'

test('fixed workflows create, confirm, execute, display outputs and restore after refresh', async ({ page, request }, info) => {
  const project = await (await request.post('/api/v1/projects', { data: { name: '合成流程验收' } })).json()
  try {
    await page.goto(`/projects/${project.id}/workflows`)
    await page.getByLabel('运行名称').fill('合成 Gaia 流程')
    await page.getByLabel('ICRS赤经 / 度 [0,360)').fill('56.75')
    await page.getByLabel('ICRS赤纬 / 度 [-90,90]').fill('24.12')
    await page.getByLabel('圆锥半径 / 角分 (0,30]').fill('5')
    await page.getByLabel('交付行上限 / 1—100').fill('10')
    await page.getByRole('button', { name: '创建待执行记录' }).click()
    await expect(page.getByRole('heading', { name: '合成 Gaia 流程' })).toBeVisible()
    await page.getByRole('button', { name: '核对并启动' }).click()
    await expect(page.getByRole('dialog')).toBeVisible()
    await page.getByRole('button', { name: '取消', exact: true }).click()
    await expect(page.getByRole('dialog')).not.toBeVisible()
    await page.getByRole('button', { name: '核对并启动' }).click()
    await page.getByRole('button', { name: '确认执行' }).click()
    await expect(page.getByText('workflow-results.zip')).toBeVisible({ timeout: 30000 })
    await expect(page.getByText('4/4 步已完成或跳过')).toBeVisible()
    await page.reload()
    await expect(page.getByText('workflow-results.zip')).toBeVisible()
    if (process.env.ASTROAGENT_RECORD_DIR) await page.screenshot({ path: path.join(process.env.ASTROAGENT_RECORD_DIR, `${info.project.name}-workflow-desktop.png`) })
    await page.setViewportSize({ width: 390, height: 844 })
    await page.getByRole('button', { name: '执行记录' }).click()
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
    if (process.env.ASTROAGENT_RECORD_DIR) await page.screenshot({ path: path.join(process.env.ASTROAGENT_RECORD_DIR, `${info.project.name}-workflow-mobile.png`) })
  } finally {
    const detail = await (await request.get(`/api/v1/projects/${project.id}`)).json()
    await request.delete(`/api/v1/projects/${project.id}`, { data: { expected_revision: detail.revision, confirm: true } })
  }
})
