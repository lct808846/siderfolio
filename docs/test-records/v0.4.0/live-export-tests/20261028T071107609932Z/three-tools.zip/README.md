# AstroAgent 查询导出包

本包来自客户端提交的快照（client_supplied_snapshot）。来源真实性未经认证；
SHA-256 只检验文件字节变化，不是来源签名或科研结论认证。
snapshot.json 保留完整语义，字段顺序、空白不保证与原 HTTP 字节相同。
answer 为模型回答；data / papers 为提交的数据库测量或书目；analysis 为程序派生量。

## 表格与完整数据

CSV 含 UTF-8 BOM，逗号分隔，CRLF 换行。null 为空；数组列为 JSON 数组字符串。
危险文本加前导单引号，Gaia source_id 统一加前导单引号以提示文本；各软件行为可能不同。
精确编号、空字符串、null 与未经处理文本以 JSON 为准。变更位置见清单。
成功查询各生成一份表；失败和无匹配不生成伪数据，其状态、错误和来源保留在快照和清单。
多次查询独立导出，不合并、去重或自动翻页。所有图使用该次全部交付行。

## 图表与科学边界

图只描述本次实际交付样本；最多 100 行且可能截断，不代表整个视场、星表或总体分布。
圆锥源仅为位置候选，不能称为确认匹配或星团成员；自行聚集不能完成成员判定。
pmra 已含 cos(dec)，未做自行传播。自行图为等比例坐标，保留负值。
观测颜色—星等图使用已有 BP-RP 和 G 视星等，亮源在上，未校正消光；
不是绝对星等 HR 图，不据此拟合年龄。缺失 BP-RP 不从别的字段补算。
视差直方图保留负/零视差，纵轴为实际行数，不是距离分布或概率密度。
不自动绘制距离、拟合或误差条；测量误差随表格导出。
距离仅在原查询启用时导出原派生值：高信噪比视差倒数和一阶随机误差，
未校正视差零点、系统误差或选择偏差，未做贝叶斯估计。
原查询条件、质量筛选、ADQL、ADS 检索式、单位、来源 UTC、截断与警告见下方元数据及 manifest.json。
图表逐行选取、排除原因、坐标、分箱边界和计数见 manifest.json。
缺少数据、失败或数值范围不可表示时跳图，包的 export_status 可为 partial。
固定输入与参数复现选行与统计；依赖、字体、时间戳和图片元数据可能变化，
不承诺跨平台 ZIP 或 PNG 逐字节相同。

## 本包查询元数据（JSON 文本）

[
  {
    "family": "simbad",
    "result_index": 0,
    "object_name": "M45",
    "status": "error",
    "source": {
      "name": "SIMBAD",
      "url": "https://simbad.cds.unistra.fr/simbad/sim-id?Ident=M45&output.format=HTML",
      "retrieved_at": "2026-10-28T07:13:51.795504Z"
    },
    "error": {
      "code": "simbad_timeout",
      "message": "SIMBAD 查询超时，请稍后重试。",
      "retryable": true
    },
    "table_path": null,
    "table_skipped_reason": "query_not_successful"
  },
  {
    "family": "ads",
    "result_index": 0,
    "query": "bibcode:2016A&A...595A...2G",
    "filters": [
      "database:astronomy"
    ],
    "rows": 5,
    "start": 0,
    "sort": "relevance",
    "status": "success",
    "total_found": 1,
    "returned_count": 1,
    "has_more": false,
    "source": {
      "name": "ADS",
      "url": "https://ui.adsabs.harvard.edu/search/q=bibcode%3A2016A%26A...595A...2G&fq=database%3Aastronomy&sort=score%20desc&start=0&p_=0",
      "retrieved_at": "2026-10-28T07:14:33.613269Z"
    },
    "error": null,
    "table_path": "tables/ads-000.csv",
    "table_skipped_reason": null
  },
  {
    "family": "gaia",
    "result_index": 0,
    "query": {
      "mode": "source_id",
      "source_id": "5853498713190525696",
      "estimate_distance": false
    },
    "release": "Gaia DR3",
    "table": "gaiadr3.gaia_source",
    "endpoint": "https://gea.esac.esa.int/tap-server/tap/sync",
    "adql": "SELECT TOP 2 source_id, ra, dec, ref_epoch, ra_error, dec_error, parallax, parallax_error, pmra, pmra_error, pmdec, pmdec_error, phot_g_mean_mag, phot_bp_mean_mag, phot_rp_mean_mag, bp_rp, radial_velocity, radial_velocity_error, ruwe, astrometric_params_solved, duplicated_source FROM gaiadr3.gaia_source WHERE source_id = 5853498713190525696",
    "maxrec": 2,
    "status": "success",
    "returned_count": 1,
    "total_found": null,
    "has_more": false,
    "truncated": false,
    "archive_overflow": false,
    "units": {
      "source_id": "1",
      "ra": "deg",
      "dec": "deg",
      "ref_epoch": "yr",
      "ra_error": "mas",
      "dec_error": "mas",
      "parallax": "mas",
      "parallax_error": "mas",
      "pmra": "mas/yr",
      "pmra_error": "mas/yr",
      "pmdec": "mas/yr",
      "pmdec_error": "mas/yr",
      "phot_g_mean_mag": "mag",
      "phot_bp_mean_mag": "mag",
      "phot_rp_mean_mag": "mag",
      "bp_rp": "mag",
      "radial_velocity": "km/s",
      "radial_velocity_error": "km/s",
      "ruwe": "1",
      "astrometric_params_solved": "1",
      "duplicated_source": "1",
      "separation_arcsec": "arcsec"
    },
    "source": {
      "name": "Gaia",
      "url": "https://gea.esac.esa.int/archive/",
      "retrieved_at": "2026-10-28T07:14:31.866942Z"
    },
    "warnings": [
      "统计仅描述本次实际交付行，不代表视场总体或星团成员；pmra 已含 cos(dec)。质量筛选会改变选择函数，阈值不能保证无污染；未额外计数，不能给出被排除数量。"
    ],
    "error": null,
    "table_path": "tables/gaia-000.csv",
    "table_skipped_reason": null
  }
]
