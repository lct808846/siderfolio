import { test, expect } from '@playwright/test'
import path from 'node:path'

test('local documents can be uploaded, searched, cited and downloaded', async ({ page, request }, info) => {
  const project = await (await request.post('/api/v1/projects', { data: { name: '合成文献验收' } })).json()
  try {
    await page.goto(`/projects/${project.id}/knowledge`)
    const raw = Buffer.from('# 合成文献\n银河潮汐 synthetic tidal evidence\n<script>window.injected=true</script>\n')
    await page.getByLabel('选择文件（断线后可重选同一文件核对）').setInputFiles({ name: 'synthetic.md', mimeType: 'text/markdown', buffer: raw })
    await page.getByRole('button', { name: '保存文件并本地解析' }).click()
    await expect(page.getByRole('heading', { name: 'synthetic.md' })).toBeVisible({ timeout: 30000 })
    await page.getByLabel('问题中的明确关键词').fill('银河潮汐')
    await page.getByRole('button', { name: '检索原文证据' }).click()
    await expect(page.getByRole('heading', { name: '找到的相关原文' })).toBeVisible()
    await page.getByRole('button', { name: '核对引用与原始版本' }).first().click()
    await expect(page.getByText('原始行', { exact: false }).first()).toBeVisible()
    expect(await page.evaluate(() => 'injected' in window)).toBe(false)
    if (process.env.ASTROAGENT_RECORD_DIR) await page.screenshot({ path: path.join(process.env.ASTROAGENT_RECORD_DIR, `${info.project.name}-knowledge-desktop.png`) })
    await page.setViewportSize({ width: 390, height: 844 })
    await page.getByRole('button', { name: '证据与原文', exact: true }).click()
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
    if (process.env.ASTROAGENT_RECORD_DIR) await page.screenshot({ path: path.join(process.env.ASTROAGENT_RECORD_DIR, `${info.project.name}-knowledge-mobile.png`) })
  } finally {
    const detail = await (await request.get(`/api/v1/projects/${project.id}`)).json()
    await request.delete(`/api/v1/projects/${project.id}`, { data: { expected_revision: detail.revision, confirm: true } })
  }
})
