# AstroAgent 查询导出包

本包来自客户端提交的快照（client_supplied_snapshot）。来源真实性未经认证；
SHA-256 只检验文件字节变化，不是来源签名或科研结论认证。
snapshot.json 保留完整语义，字段顺序、空白不保证与原 HTTP 字节相同。
answer 为模型回答；data / papers 为提交的数据库测量或书目；analysis 为程序派生量。

## 表格与完整数据

CSV 含 UTF-8 BOM，逗号分隔，CRLF 换行。null 为空；数组列为 JSON 数组字符串。
危险文本加前导单引号，Gaia source_id 统一加前导单引号以提示文本；各软件行为可能不同。
精确编号、空字符串、null 与未经处理文本以 JSON 为准。变更位置见清单。
成功查询各生成一份表；失败和无匹配不生成伪数据，其状态、错误和来源保留在快照和清单。
多次查询独立导出，不合并、去重或自动翻页。所有图使用该次全部交付行。

## 图表与科学边界

图只描述本次实际交付样本；最多 100 行且可能截断，不代表整个视场、星表或总体分布。
圆锥源仅为位置候选，不能称为确认匹配或星团成员；自行聚集不能完成成员判定。
pmra 已含 cos(dec)，未做自行传播。自行图为等比例坐标，保留负值。
观测颜色—星等图使用已有 BP-RP 和 G 视星等，亮源在上，未校正消光；
不是绝对星等 HR 图，不据此拟合年龄。缺失 BP-RP 不从别的字段补算。
视差直方图保留负/零视差，纵轴为实际行数，不是距离分布或概率密度。
不自动绘制距离、拟合或误差条；测量误差随表格导出。
距离仅在原查询启用时导出原派生值：高信噪比视差倒数和一阶随机误差，
未校正视差零点、系统误差或选择偏差，未做贝叶斯估计。
原查询条件、质量筛选、ADQL、ADS 检索式、单位、来源 UTC、截断与警告见下方元数据及 manifest.json。
图表逐行选取、排除原因、坐标、分箱边界和计数见 manifest.json。
缺少数据、失败或数值范围不可表示时跳图，包的 export_status 可为 partial。
固定输入与参数复现选行与统计；依赖、字体、时间戳和图片元数据可能变化，
不承诺跨平台 ZIP 或 PNG 逐字节相同。

## 本包查询元数据（JSON 文本）

    [
      {
        "family": "gaia",
        "result_index": 0,
        "query": {
          "dec_deg": 24.12,
          "estimate_distance": false,
          "limit": 100,
          "mode": "cone",
          "parallax_snr_min": null,
          "ra_deg": 56.75,
          "radius_arcmin": 5.0,
          "ruwe_max": null
        },
        "release": "Gaia DR3",
        "table": "gaiadr3.gaia_source",
        "endpoint": "https://gea.esac.esa.int/tap-server/tap/sync",
        "adql": "SELECT TOP 101 source_id, ra, dec, ref_epoch, ra_error, dec_error, parallax, parallax_error, pmra, pmra_error, pmdec, pmdec_error, phot_g_mean_mag, phot_bp_mean_mag, phot_rp_mean_mag, bp_rp, radial_velocity, radial_velocity_error, ruwe, astrometric_params_solved, duplicated_source, DISTANCE(POINT('ICRS', ra, dec), POINT('ICRS', 56.75, 24.12)) AS separation_deg FROM gaiadr3.gaia_source WHERE 1 = CONTAINS(POINT('ICRS', ra, dec), CIRCLE('ICRS', 56.75, 24.12, 0.08333333333333333)) ORDER BY separation_deg ASC, source_id ASC",
        "maxrec": 101,
        "status": "success",
        "returned_count": 100,
        "total_found": null,
        "has_more": false,
        "truncated": false,
        "archive_overflow": false,
        "units": {
          "astrometric_params_solved": "1",
          "bp_rp": "mag",
          "dec": "deg",
          "dec_error": "mas",
          "duplicated_source": "1",
          "parallax": "mas",
          "parallax_error": "mas",
          "phot_bp_mean_mag": "mag",
          "phot_g_mean_mag": "mag",
          "phot_rp_mean_mag": "mag",
          "pmdec": "mas/yr",
          "pmdec_error": "mas/yr",
          "pmra": "mas/yr",
          "pmra_error": "mas/yr",
          "ra": "deg",
          "ra_error": "mas",
          "radial_velocity": "km/s",
          "radial_velocity_error": "km/s",
          "ref_epoch": "yr",
          "ruwe": "1",
          "separation_arcsec": "arcsec",
          "source_id": "1"
        },
        "source": {
          "name": "Gaia",
          "url": "https://example.invalid/synthetic-gaia",
          "retrieved_at": "2026-10-29T14:42:31.262386Z"
        },
        "warnings": [
          "合成验收数据，不是实际观测。"
        ],
        "error": null,
        "table_path": "tables/gaia-000.csv",
        "table_skipped_reason": null
      }
    ]
